package com.example.demo;



import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext(new String[] {"Spring-Customer.xml"});

		NoScope mensajeA = (NoScope)context.getBean("NoScope");
		mensajeA.setMensaje("Prueba A");
		System.out.println("Mensaje A: " + mensajeA.getMensaje());

		NoScope mensajeB = (NoScope)context.getBean("NoScope");
		System.out.println("Mensaje B: " + mensajeB.getMensaje());
		
		ConScope mensajeC = (ConScope)context.getBean("ConScope");
		mensajeC.setMensaje("Prueba c");
		System.out.println("Mensaje C: " + mensajeC.getMensaje());

		ConScope mensajeD = (ConScope)context.getBean("ConScope");
		System.out.println("Mensaje D: " + mensajeD.getMensaje());
		
		AnotacionScope mensajeE = (AnotacionScope)context.getBean("AnotacionScope");
		mensajeE.setMensaje("Prueba E");
		System.out.println("Mensaje C: " + mensajeE.getMensaje());

		AnotacionScope mensajeF = (AnotacionScope)context.getBean("AnotacionScope");
		System.out.println("Mensaje D: " + mensajeF.getMensaje());
	}

}
