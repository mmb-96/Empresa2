import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Consulta3 {

	public static void main(String[] args) throws ClassNotFoundException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		try {
			System.out.println("Estabeciendo conexi�n:");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/prueba", "root", "1234");
			Statement stm = con.createStatement();

			
			String sql = "SELECT a.nombre, count(idalumno) FROM alumno_asignatura al join asignatura a on al.idasignatura = a.idasignatura GROUP BY nombre;";
			ResultSet rs = stm.executeQuery(sql);
			
			while(rs.next()) {
				String nombre = rs.getString("nombre");
				int total = rs.getInt(2);
				
				System.out.println("Los asignatura " + nombre + " tiene " + total + " alumnos.");
			}
			
			rs.close();
			stm.close();
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}