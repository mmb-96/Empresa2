import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Consulta1 {

	public static void main(String[] args) throws ClassNotFoundException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		try {
			System.out.println("Estabeciendo conexi�n:");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/prueba", "root", "1234");
			Statement stm = con.createStatement();

			
			String sql = "Select t.nombre from titulacion t join asignatura a on t.idtitulacion = a.idtitulacion where a.idasignatura = (select idasignatura from alumno_asignatura group by idasignatura having count(idalumno) >=3);";
			ResultSet rs = stm.executeQuery(sql);
			
			while(rs.next()) {
				String nombre = rs.getString(1);
				
				System.out.println("La asignatura con tres o m�s alumno es " + nombre);
			}
			
			rs.close();
			stm.close();
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
