import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Consulta2 {

	public static void main(String[] args) throws ClassNotFoundException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		try {
			System.out.println("Estabeciendo conexi�n:");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/prueba", "root", "1234");
			Statement stm = con.createStatement();

			
			String sql = "select concat(nombre,' ',apellido,' ',telefono) NombreCompleto, concat(direccioncalle,' ',direccionnum) Direccion from persona;";
			ResultSet rs = stm.executeQuery(sql);
			
			while(rs.next()) {
				String nombre = rs.getString("NombreCompleto");
				String dir = rs.getString("Direccion");
				
				System.out.println("Los datos de las personas son " + nombre + " vive en " + dir);
			}
			
			rs.close();
			stm.close();
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}