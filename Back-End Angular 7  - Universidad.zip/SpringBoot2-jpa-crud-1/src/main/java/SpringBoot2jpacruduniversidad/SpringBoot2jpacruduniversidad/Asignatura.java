package SpringBoot2jpacruduniversidad.SpringBoot2jpacruduniversidad;
import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Asignatura")
public class Asignatura implements Serializable {
	@Id
	@Column(name="Idasignatura")
	private String idasignatura;
	
	@Column(name="Nombre")
	private String nombre;
	
	@Column(name="Creditos")
	private Integer creditos;
	
	@Column(name="Cuatrimestre")
	private Integer cuatrimestre;
	
	@Column(name="Costebasico")
	private Integer costebasico;
	
	private String idprofesor;
	
	private String idtitulacion;
	
	@Column(name="Curso")
	private Integer curso;
	
	
	public Asignatura(){
		
	}
	
	public Asignatura(String idasignatura, String nombre, Integer creditos, Integer cuatrimestre, Integer costebasico,
			String idprofesor, String idtitulacion, Integer curso) {
		this.idasignatura = idasignatura;
		this.nombre = nombre;
		this.creditos = creditos;
		this.cuatrimestre = cuatrimestre;
		this.costebasico = costebasico;
		this.idprofesor = idprofesor;
		this.idtitulacion = idtitulacion;
		this.curso = curso;
	}

	public String getIdasignatura() {
		return idasignatura;
	}

	public void setIdasignatura(String idasignatura) {
		this.idasignatura = idasignatura;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Integer getCreditos() {
		return creditos;
	}

	public void setCreditos(Integer creditos) {
		this.creditos = creditos;
	}

	public Integer getCuatrimestre() {
		return cuatrimestre;
	}

	public void setCuatrimestre(Integer cuatrimestre) {
		this.cuatrimestre = cuatrimestre;
	}

	public Integer getCostebasico() {
		return costebasico;
	}

	public void setCostebasico(Integer costebasico) {
		this.costebasico = costebasico;
	}

	public String getIdprofesor() {
		return idprofesor;
	}

	public void setIdprofesor(String idprofesor) {
		this.idprofesor = idprofesor;
	}

	public String getIdtitulacion() {
		return idtitulacion;
	}

	public void setIdtitulacion(String idtitulacion) {
		this.idtitulacion = idtitulacion;
	}

	public Integer getCurso() {
		return curso;
	}

	public void setCurso(Integer curso) {
		this.curso = curso;
	}
	
	@Override
	public String toString() {
		return "Asignatura [idasignatura=" + idasignatura + ", nombre=" + nombre + ", creditos=" + creditos
				+ ", cuatrimestre=" + cuatrimestre + ", costebasico=" + costebasico + ", idprofesor=" + idprofesor
				+ ", idtitulacion=" + idtitulacion + ", Curso=" + curso + ", alumno_asignatura=" 
				+ "]";
	}
	


}