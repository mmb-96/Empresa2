package SpringBoot2jpacruduniversidad.SpringBoot2jpacruduniversidad;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javassist.tools.web.BadHttpRequest;

@RestController
@RequestMapping(path = "/asignatura")
public class AsignaturaController {
	
	@Autowired
    private AsignaturaRepo repository;

    @GetMapping
    public Iterable<Asignatura> findAll() {
        return repository.findAll();
    }

    @GetMapping(path = "/{idasignatura}")
    public Optional<Asignatura> find(@PathVariable("idasignatura") String idasignatura) {
        return repository.findById(idasignatura);
    }

    @PostMapping(consumes = "application/json")
    public Asignatura create(@RequestBody Asignatura asignatura) {
        return repository.save(asignatura);
    }

    @DeleteMapping(path = "/{idasignatura}")
    public void delete(@PathVariable("idasignatura") String idasignatura) {
        repository.deleteById(idasignatura);
    }

    @PutMapping(path = "/{idasignatura}")
    public Asignatura update(@PathVariable("idasignatura") String idasignatura, @RequestBody Asignatura asignatura) throws BadHttpRequest {
        if (repository.existsById(idasignatura)) {
            asignatura.setIdasignatura(idasignatura);
            return repository.save(asignatura);
        } else {
            throw new BadHttpRequest();
        }
    }
}