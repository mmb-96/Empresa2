import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Main {
	public static void main(String[] args) throws SQLException {
		final String url = "jdbc:mysql://localhost:3306/transacciones"; 
		final String user = "root";
		final String pass = "1234";
		
		String insert1 = "insert into prueba1 values (?,?)";
		String insert2 = "insert into prueba2 values (?,?)";
		String update1 = "update prueba1 SET nombre = ? WHERE id = ?";
		String update2 = "update prueba2 SET nombre = ? WHERE id = ?";
		
		PreparedStatement insert = null;
		PreparedStatement update = null;
		
		Connection con1 = null;
		Connection con2 = null;
		Connection con3 = null;
		Connection con4 = null;
		Connection con5 = null;
		Connection con6 = null;
		Connection con7 = null;
		Connection con8 = null;
				
		try {
			
			con1 = DriverManager.getConnection(url, user, pass);
			con2 = DriverManager.getConnection(url, user, pass);
			con3 = DriverManager.getConnection(url, user, pass);
			con4 = DriverManager.getConnection(url, user, pass);
			con5 = DriverManager.getConnection(url, user, pass);
			con6 = DriverManager.getConnection(url, user, pass);
			con7 = DriverManager.getConnection(url, user, pass);
			con8 = DriverManager.getConnection(url, user, pass);

			con1.setAutoCommit(false);
			con2.setAutoCommit(false);
			con3.setAutoCommit(false);
			con4.setAutoCommit(false);
			con5.setAutoCommit(false);
			con6.setAutoCommit(false);
			con7.setAutoCommit(false);
			con8.setAutoCommit(false);
			
			con1.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
			con2.setTransactionIsolation(Connection.TRANSACTION_READ_UNCOMMITTED);		
			con3.setTransactionIsolation(Connection.TRANSACTION_READ_UNCOMMITTED);		
			con4.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);		
			con5.setTransactionIsolation(Connection.TRANSACTION_READ_UNCOMMITTED);		
			con6.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);		
			con7.setTransactionIsolation(Connection.TRANSACTION_READ_UNCOMMITTED);		
			con8.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);		
			
			insert = con1.prepareStatement(insert2);
			insert.setInt(1, 1);
			insert.setString(2, "Manuel");
			insert.executeUpdate();
			
			con1.commit();
			
			System.out.println("Usuario 1 ha insertado");
						
			Statement st = con2.createStatement();
			ResultSet rs = st.executeQuery("SELECT * FROM prueba2 WHERE id = 1");
			
			System.out.println("SELECT del usuario 2");
			while(rs.next()) {
				System.out.println(rs.getString(2));
			}
			
			con2.commit();
			
			insert = con3.prepareStatement(insert1);
			insert.setInt(1, 2);
			insert.setString(2, "Jose");
			insert.executeUpdate();	
			
			System.out.println("Usuario 3 ha insertado");
			
			update = con4.prepareStatement(update2);
			update.setString(1, "Luis");
			update.setInt(2, 1);
			update.executeUpdate();
			
			System.out.println("Usuario 4 ha actualizado");
			
			con3.commit();
			con4.commit();
			
			st = con5.createStatement();
			rs = st.executeQuery("SELECT * FROM prueba2 WHERE id = 1");
			System.out.println("SELECT del usuario 5");
			while(rs.next()) {
				System.out.println(rs.getString(2));
			}
			
			con5.commit();
			
			insert = con6.prepareStatement(insert1);
			insert.setInt(1, 3);
			insert.setString(2, "Oktay");
			insert.executeUpdate();
			
			con6.commit();
			
			System.out.println("Usuario 6 ha insertado");
			
			update = con7.prepareStatement(update1);
			update.setString(1, "Pepe");
			update.setInt(2, 2);
			update.executeUpdate();
			
			System.out.println("Usuario 7 ha actualizado");
			
			update = con8.prepareStatement("DELETE FROM prueba1 WHERE id = 3");
			update.executeUpdate();
			
			System.out.println("Usuario 8 ha borrado");
			
			con7.commit();
			con8.commit();
			
			st = con1.createStatement();
			rs = st.executeQuery("SELECT * FROM prueba2");
			System.out.println("SELECT final de prueba2");
			while(rs.next()) {
				System.out.println(rs.getString(2));
			}
			
			st = con1.createStatement();
			rs = st.executeQuery("SELECT * FROM prueba1");
			System.out.println("SELECT final de prueba1");
			while(rs.next()) {
				System.out.println(rs.getString(2));
			}
			
		} catch (SQLException e) {
			System.out.println(e);
			con1.rollback();
			con2.rollback();
			con3.rollback();
			con4.rollback();
			con5.rollback();
			con6.rollback();
			con7.rollback();
			con8.rollback();
		}finally {
			con1.close();
			con2.close();
			con3.close();
			con4.close();
			con5.close();
			con6.close();
			con7.close();
			con8.close();
		}
	}

}
