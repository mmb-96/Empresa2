package etc;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javassist.tools.web.BadHttpRequest;

@RestController
@RequestMapping(path = "/persona")
public class PersonaController {
	
	@Autowired
    private PersonaRepo repository;

    @GetMapping
    public Iterable<Persona> findAll() {
        return repository.findAll();
    }

    @GetMapping(path = "/{dni}")
    public Optional<Persona> find(@PathVariable("dni") String dni) {
        return repository.findById(dni);
    }

    @PostMapping(consumes = "application/json")
    public Persona create(@RequestBody Persona persona) {
        return repository.save(persona);
    }

    @DeleteMapping(path = "/{dni}")
    public void delete(@PathVariable("dni") String dni) {
        repository.deleteById(dni);
    }

    @PutMapping(path = "/{dni}")
    public Persona update(@PathVariable("dni") String dni, @RequestBody Persona persona) throws BadHttpRequest {
        if (repository.existsById(dni)) {
            persona.setDni(dni);
            return repository.save(persona);
        } else {
            throw new BadHttpRequest();
        }
    }
	
}