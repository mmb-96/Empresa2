package etc;
import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Titulacion")
public class Titulacion implements Serializable{
	
	@Id
	@Column(name = "Idtitulacion")
	private String idtitulacion;
	
	@Column(name = "Nombre")
	private String nombre;
	
	@OneToMany(mappedBy="idtitulacion", cascade= CascadeType.ALL)
	private Set<Asignatura> Asignatura;
	
	public Titulacion() {
		
	}

	public Titulacion(String idtitulacion, String nombre) {
		this.idtitulacion = idtitulacion;
		this.nombre = nombre;
	}

	public String getIdtitulacion() {
		return idtitulacion;
	}

	public void setIdtitulacion(String idtitulacion) {
		this.idtitulacion = idtitulacion;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public String toString() {
		return "Titulacion [idtitulacion=" + idtitulacion + ", nombre=" + nombre + "]\n";
	}
	
	
}