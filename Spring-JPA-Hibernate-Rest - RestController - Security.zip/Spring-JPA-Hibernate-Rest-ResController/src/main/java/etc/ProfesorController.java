package etc;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javassist.tools.web.BadHttpRequest;

@RestController
@RequestMapping(path = "/profesor")
public class ProfesorController {
	
	@Autowired
    private ProfesorRepo repository;

    @GetMapping
    public Iterable<Profesor> findAll() {
        return repository.findAll();
    }

    @GetMapping(path = "/{idprofesor}")
    public Optional<Profesor> find(@PathVariable("idprofesor") String idprofesor) {
        return repository.findById(idprofesor);
    }

    @PostMapping(consumes = "application/json")
    public Profesor create(@RequestBody Profesor profesor) {
        return repository.save(profesor);
    }

    @DeleteMapping(path = "/{idprofesor}")
    public void delete(@PathVariable("idprofesor") String idprofesor) {
        repository.deleteById(idprofesor);
    }

    @PutMapping(path = "/{dni}")
    public Profesor update(@PathVariable("idprofesor") String idprofesor, @RequestBody Profesor profesor) throws BadHttpRequest {
        if (repository.existsById(idprofesor)) {
            profesor.setIdprofesor(idprofesor);
            return repository.save(profesor);
        } else {
            throw new BadHttpRequest();
        }
    }
}