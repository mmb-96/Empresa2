package etc;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javassist.tools.web.BadHttpRequest;

@RestController
@RequestMapping(path = "/titulacion")
public class TitulacionController {
	
	@Autowired
	private TitulacionRepo titulacionRepo;
	
	@GetMapping
    public Iterable<Titulacion> findAll() {
        return titulacionRepo.findAll();
    }

    @GetMapping(path = "/{idtitulacion}")
    public Optional<Titulacion> find(@PathVariable("idtitulacion") String idtitulacion) {
        return titulacionRepo.findById(idtitulacion);
    }

    @PostMapping(consumes = "application/json")
    public Titulacion create(@RequestBody Titulacion titulacion) {
        return titulacionRepo.save(titulacion);
    }

    @DeleteMapping(path = "/{idtitulacion}")
    public void delete(@PathVariable("idtitulacion") String idtitulacion) {
    	titulacionRepo.deleteById(idtitulacion);
    }

    @PutMapping(path = "/{idtitulacion}")
    public Titulacion update(@PathVariable("idtitulacion") String idtitulacion, @RequestBody Titulacion titulacion) throws BadHttpRequest {
        if (titulacionRepo.existsById(idtitulacion)) {
        	titulacion.setIdtitulacion(idtitulacion);
            return titulacionRepo.save(titulacion);
        } else {
            throw new BadHttpRequest();
        }
    }

}
