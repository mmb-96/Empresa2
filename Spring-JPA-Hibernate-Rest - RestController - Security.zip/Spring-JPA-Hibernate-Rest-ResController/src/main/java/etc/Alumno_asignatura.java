package etc;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="Alumno_asignatura")
public class Alumno_asignatura implements Serializable{
	
	@Embeddable
	public static class CompuestaPK implements Serializable {
		
		public CompuestaPK() {
		}
		
		@ManyToOne(targetEntity=Alumno.class)
		@JoinColumn(name = "idalumno", referencedColumnName = "idalumno")
		private Alumno idalumno;
		
		@ManyToOne
		@JoinColumn(name = "idasignatura", referencedColumnName = "idasignatura")
		private Asignatura idasignatura;
		
		@Column(name="Numeromatricula")
		private int Numeromatricula;

		public CompuestaPK(Alumno idalumno, Asignatura idasignatura, int numeromatricula) {
			this.idalumno = idalumno;
			this.idasignatura = idasignatura;
			Numeromatricula = numeromatricula;
		}

		@Override
		public String toString() {
			return "idalumno=" + idalumno.getIdalumno() + ", idasignatura=" + idasignatura.getIdasignatura() + ", Numeromatricula="
					+ Numeromatricula;
		}
			
	}

	@EmbeddedId
	CompuestaPK pk;
	
	public Alumno_asignatura() {
		
	}

	public Alumno_asignatura(CompuestaPK pk) {
		super();
		this.pk = pk;
	}
	
	public CompuestaPK getPk() {
		return pk;
	}

	public void setPk(CompuestaPK pk) {
		this.pk = pk;
	}

	@Override
	public String toString() {
		return pk.toString();
	}

}