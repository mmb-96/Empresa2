import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class Main {

	public static void main(String[] args) {
		SessionFactory sessionFactory;
		try {
		Configuration configuration = new Configuration();
		configuration.configure();
		ServiceRegistry serviceRegistry = new ServiceRegistryBuilder().applySettings(configuration.getProperties()).buildServiceRegistry();
		sessionFactory = configuration.buildSessionFactory(serviceRegistry);
		Session session = sessionFactory.openSession();
		Alumno a = new Alumno("1117");
		a.setDni("1111122X");
		Profesor pr = new Profesor("P114");
		pr.setDni("1111123X");
		Titulacion ti = new Titulacion("1115", "Prueba");
		Asignatura as = new Asignatura("1114", "Prueba2", 5, 2, 5, pr, ti, 1);
		Alumno_asignatura aa = new Alumno_asignatura(a, as, 1);

			session.beginTransaction();
			session.save(pr);
			session.save(a);
			session.save(ti);
			session.save(as);
			session.save(aa);
			session.getTransaction().commit();
			
			Query query = session.createQuery("SELECT p FROM Persona p");
			List<Persona> listDatos = query.list();
			for (Persona datos : listDatos) {
			     System.out.println(datos.toString());
			}
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
				
	}

}
