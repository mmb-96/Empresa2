import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
@Entity
@Table(name="Alumno_asignatura")
public class Alumno_asignatura implements Serializable{
	
	@Id
	@ManyToOne
	@JoinColumn(name = "idalumno", referencedColumnName = "idalumno")
	private Alumno idalumno;
	
	@Id
	@ManyToOne
	@JoinColumn(name = "idasignatura", referencedColumnName = "idasignatura")
	private Asignatura idasignatura;
	
	@Id
	@Column(name="Numeromatricula")
	private int Numeromatricula;
	
	public Alumno_asignatura() {
		
	}

	public Alumno_asignatura(Alumno idalumno, Asignatura idasignatura, int nummatricula) {
		this.idalumno = idalumno;
		this.idasignatura = idasignatura;
		this.Numeromatricula = nummatricula;
	}

	public Alumno getIdalumno() {
		return idalumno;
	}

	public void setIdalumno(Alumno idalumno) {
		this.idalumno = idalumno;
	}

	public Asignatura getIdasignatura() {
		return idasignatura;
	}

	public void setIdasignatura(Asignatura idasignatura) {
		this.idasignatura = idasignatura;
	}

	public int getNummatricula() {
		return Numeromatricula;
	}

	public void setNummatricula(int nummatricula) {
		this.Numeromatricula = nummatricula;
	}
}