import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Alumno")
public class Alumno extends Persona {
	

	@Column(name="idalumno")
	private String idalumno;

	@OneToMany(mappedBy="idalumno")
	private Set<Alumno_asignatura> Alumno_asignatura;
	
	public Alumno() {
		
	}

	public Alumno(String idalumno) {
		this.idalumno = idalumno;
	}

	public String getIdalumno() {
		return idalumno;
	}

	public void setIdalumno(String idalumno) {
		this.idalumno = idalumno;
	}
	
	public void setAlumno_asignatura(Set<Alumno_asignatura> alumno_asignatura) {
		this.Alumno_asignatura = alumno_asignatura;
	}
	
	public Set<Alumno_asignatura> getAlumno_asignatura() {
		return Alumno_asignatura;
	}
}