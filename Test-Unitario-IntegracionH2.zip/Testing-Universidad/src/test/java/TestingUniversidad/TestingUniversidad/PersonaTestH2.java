package TestingUniversidad.TestingUniversidad;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.*;

import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

@DataJpaTest
@RunWith(SpringRunner.class)
public class PersonaTestH2 {
	
    @Autowired
    private PersonaRepo personaRepo;
    
    @Test
    public void testFindByNameLength() {
    	personaRepo.save(new Persona("16161617A","Luis","Ramirez","Haro","Pez",34,"941111111",1));
        Collection<Persona> persona = personaRepo.findByNameLength(4);
        assertThat(persona.size()).isEqualTo(2);
    }
    
    @Test
    public void testFindByDani() {
    	Collection<Persona> persona = personaRepo.findByDni("30235421N");
    	assertThat(persona.size()).isNotEqualTo(1);
    }
    
    @Test
    public void testFindAll() {
    	Collection<Persona> persona = personaRepo.findAll();
    	assertThat(persona.size()).isEqualTo(2);    	
    }
    
    @Test
    public void deleteOne() {
    	Persona per = new Persona("16161616A","Luis","Ramirez","Haro","Pez",34,"941111111",1);
    	personaRepo.delete(per);
    	Collection<Persona> persona = personaRepo.findAll();
    	assertThat(persona.size()).isEqualTo(1);
    }
    
    @Test
    public void updatePersona() {
    	Persona per = new Persona("17171717A","Bea","Beltran","Madrid","Gran Va",23,"912121212",0);
    	personaRepo.save(per);
    	Persona persona = personaRepo.findByDniOnyPerson("17171717A");
    	assertThat(persona.getNombre().equals(per.getNombre()));
    }
    
}
