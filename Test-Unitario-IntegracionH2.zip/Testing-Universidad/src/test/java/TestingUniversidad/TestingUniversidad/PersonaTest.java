/**
 * Test unitario con mock
 */
package TestingUniversidad.TestingUniversidad;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;


import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

public class PersonaTest {

	@InjectMocks 
	private PersonaService personaService;
	 
	@Mock
	private PersonaDAO personaDao;
	 
	  @Test
	  public void testobtenerTodo() {
		  initMocks(this);
		  when(personaDao.obtenerTodo("30235421N")).thenReturn(getMeTestPersona());
		  Persona per = personaService.bucarPorDni("30235421N");
		  assertNotNull(per);
		  assertEquals("30235421N", per.getDni());
	  }
	  
	  @Test
	  public void testobtenerTelefono() {
		  initMocks(this);
		  when(personaDao.obtenerTelefono("608707624")).thenReturn(getMeTestPersona());
		  Persona per = personaService.obtenerTelefono("608707624");
		  assertNotNull(per);
		  assertEquals("608707624", per.getTelefono());
	  }
	  
	  @Test
	  public void testobtenerNombre() {
		  initMocks(this);
		  when(personaDao.obtenerNombre("Manuel")).thenReturn(getMeTestPersona());
		  Persona per = personaService.obtenerNombre("Manuel");
		  assertNotNull(per);
		  assertEquals("Manuel", per.getNombre());
	  }

	 
	  private Persona getMeTestPersona() {
	    Persona per = new Persona();
	    per.setNombre("Manuel");
	    per.setApellido("Melero");
	    per.setCiudad("Sevilla");
	    per.setDireccioncalle("Costa y llobera");
	    per.setDireccionnum(107);
	    per.setTelefono("608707624");
	    per.setVaron(1);
	    per.setDni("30235421N");
	    return per;
	  }
}