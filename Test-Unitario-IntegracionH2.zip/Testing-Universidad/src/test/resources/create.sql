CREATE table Persona (
dni varchar(11) primary key,
Nombre varchar(30),
Apellido varchar(30),
Ciudad varchar(15),
Direccioncalle varchar(30),
Direccionnum int,
Telefono varchar(9),
Varon int
)