DELETE FROM Persona;
insert into Persona (dni, Nombre, Apellido, Ciudad, Direccioncalle, Direccionnum, Telefono,Varon) values ('16161616A','Luis','Ramirez','Haro','Pez',34,'941111111',1);
insert into Persona (dni, Nombre, Apellido, Ciudad, Direccioncalle, Direccionnum, Telefono,Varon) values ('17171717A','Laura','Beltran','Madrid','Gran Va',23,'912121212',0);