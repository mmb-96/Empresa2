package TestingUniversidad.TestingUniversidad;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

@Component
public class PersonaDAO {
	
	@Query("SELECT p FROM Persona p WHERE dni = :dni")
	
	public Persona obtenerTodo(@Param ("dni")String dni) {
		return obtenerTodo(dni);
		
	}
	
	@Query("SELECT * FROM Persona p WHERE telefono = :telefono")
	
	public Persona obtenerTelefono(@Param ("telefono")String telefono) {
		return obtenerTelefono(telefono);
		
	}
	@Query("SELECT * FROM Persona p WHERE nombre = :nombre")

	public Persona obtenerNombre(@Param ("nombre")String nombre) {
		return obtenerNombre(nombre);
	}
	
	

}
