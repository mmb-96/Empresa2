package TestingUniversidad.TestingUniversidad;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PersonaService {
	
	@Autowired
	private PersonaDAO personaDao;
	
	public Persona bucarPorDni(String dni) {
		return personaDao.obtenerTodo(dni);
	}
	
	public Persona obtenerNombre(String nombre) {
		return personaDao.obtenerNombre(nombre);
	}
	
	public Persona obtenerTelefono(String Telefono) {
		return personaDao.obtenerTelefono(Telefono);
		
	}
	

}
