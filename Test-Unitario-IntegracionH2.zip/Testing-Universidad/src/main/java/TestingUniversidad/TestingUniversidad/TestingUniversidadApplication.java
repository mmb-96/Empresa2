package TestingUniversidad.TestingUniversidad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestingUniversidadApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestingUniversidadApplication.class, args);
	}

}
