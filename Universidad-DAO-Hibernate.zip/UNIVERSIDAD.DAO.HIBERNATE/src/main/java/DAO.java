import java.io.Serializable;
import java.util.List;

public interface DAO<T, Id extends Serializable>{
	
	public void insertar(T entity);
	
	public void actualizar(T entity);
		
	public void borrar(T entity);
	
	public List<T> buscarTodo();
}
