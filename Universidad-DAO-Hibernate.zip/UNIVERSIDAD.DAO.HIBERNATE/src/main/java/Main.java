
public class Main {

	public static void main(String[] args) {
		PersonaDao pd = new PersonaDao();
		Persona p = new Persona("7Z", "aa", "aa", "aa", "aa", 1, "123", 1);
		
		AlumanoDao ad = new AlumanoDao();
		Alumno a = new Alumno("3X");
		a.setDni("6Z");
		
		ProfesorDao prd = new ProfesorDao();
		Profesor pr = new Profesor("1X");
		pr.setDni("8Z");
		
		TitulacionDao tid = new TitulacionDao();
		Titulacion ti = new Titulacion("2T", "Hola");
		
		AsignaturaDao asd = new AsignaturaDao();
		Asignatura as = new Asignatura("1AS", "Hola", 5, 2, 5, pr, ti, 5);
		
		Alumno_asignaturaDao aad = new Alumno_asignaturaDao();
		Alumno_asignatura aa = new Alumno_asignatura(a, as, 2);
		
//		//Persona
//		pd.abreSessionTransaccion();
//		pd.insertar(p);
//		pd.cierraSessionTransaccion();
//		pd.abreSessionTransaccion();
//		System.out.println(pd.buscarTodo());
//		pd.cierraSessionTransaccion();
//		pd.abreSessionTransaccion();
//		pd.borrar(p);
//		pd.cierraSessionTransaccion();
//		pd.abreSessionTransaccion();
//		System.out.println(pd.buscarTodo());
//		pd.cierraSessionTransaccion();
//		
//		//Alumno
//		ad.abreSessionTransaccion();
//		ad.insertar(a);
//		a.setNombre("Hola");
//		a.setApellido("Mundo");
//		ad.actualizar(a);
//		ad.cierraSessionTransaccion();
//		ad.abreSessionTransaccion();
//		System.out.println(ad.buscarTodo());
//		ad.cierraSessionTransaccion();
//		
//		//Profesor
//		prd.abreSessionTransaccion();
//		prd.insertar(pr);
//		prd.cierraSessionTransaccion();
//		prd.abreSession();
//		for (Profesor pro : prd.buscarTodo()) {
//			System.out.println(pro);
//		}
//		prd.cierraSession();
		
		//Titulacion
		tid.abreSessionTransaccion();
//		tid.insertar(ti);
		ti.setNombre("Adios");
		tid.actualizar(ti);
		tid.cierraSessionTransaccion();
		tid.abreSession();
		System.out.println(tid.buscarTodo());
		tid.cierraSession();
		
//		//Asignatura
//		asd.abreSessionTransaccion();
//		asd.insertar(as);
//		asd.cierraSessionTransaccion();
//		
//		//Alumno_asignatura
//		aad.abreSessionTransaccion();
//		aad.insertar(aa);
//		aad.cierraSessionTransaccion();
	}

}
