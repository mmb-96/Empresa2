package Clases;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Profesor")
public class Profesor extends Persona {
	
	@Column(name="Idprofesor")
	private String idprofesor;
	
	
	@OneToMany(mappedBy="idprofesor")
	private Set<Asignatura> Asignatura;
	
	public Profesor() {
		
	}

	public Profesor(String idprofesor) {
		this.idprofesor = idprofesor;
	}

	public String getIdprofesor() {
		return idprofesor;
	}

	public void setIdprofesor(String idprofesor) {
		this.idprofesor = idprofesor;
	}


	public Set<Asignatura> getAsignatura() {
		return Asignatura;
	}

	public void setAsignatura(Set<Asignatura> asignatura) {
		Asignatura = asignatura;
	}

	@Override
	public String toString() {
		return super.toString() + "Profesor [idprofesor=" + idprofesor + "]";
	}
	
	
}