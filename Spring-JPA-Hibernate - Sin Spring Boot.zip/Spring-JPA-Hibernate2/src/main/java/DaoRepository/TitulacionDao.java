package DaoRepository;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

import Clases.Titulacion;

@Repository
public class TitulacionDao implements DAO<Titulacion, String> {
	
	@PersistenceContext
	private EntityManager em;
   
	@Override
	public void insertar(Titulacion entity) {
		em.persist(entity);		
	}

	@Override
	public void borrar(Titulacion entity) {
		em.remove(entity);		
	}

	@Override
	public List<Titulacion> buscarTodo() {
		List<Titulacion> t = (List<Titulacion>) em.createQuery("from Titulacion").getResultList();
        return t;
	}
}