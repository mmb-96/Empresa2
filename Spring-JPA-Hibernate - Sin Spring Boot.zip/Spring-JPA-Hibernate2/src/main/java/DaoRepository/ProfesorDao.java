package DaoRepository;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

import Clases.Profesor;

@Repository
public class ProfesorDao implements DAO<Profesor, String> {
	
	@PersistenceContext
	private EntityManager em;

	@Override
	public void insertar(Profesor entity) {
		em.persist(entity);
	}

	@Override
	public void borrar(Profesor entity) {
		em.remove(entity);	
	}

	@Override
	public List<Profesor> buscarTodo() {
		List<Profesor> a = (List<Profesor>)em.createQuery("from Profesor").getResultList();
        return a;
	}
}