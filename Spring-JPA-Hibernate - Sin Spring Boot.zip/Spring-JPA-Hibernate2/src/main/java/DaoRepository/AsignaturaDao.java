package DaoRepository;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

import Clases.Asignatura;

@Repository
public class AsignaturaDao implements DAO<Asignatura, String> {
	
	@PersistenceContext
	private EntityManager em;

	@Override
	public void insertar(Asignatura entity) {
		em.persist(entity);	
	}

	@Override
	public void borrar(Asignatura entity) {
		em.remove(entity);
	}

	@Override
	public List<Asignatura> buscarTodo() {
		List<Asignatura> a = (List<Asignatura>) em.createQuery("from Profesor").getResultList();
        return a;
	}
}