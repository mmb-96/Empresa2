package DaoRepository;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

import Clases.Alumno_asignatura;

@Repository
public class Alumno_asignaturaDao implements DAO<Alumno_asignatura, String> {
	
	@PersistenceContext
	private EntityManager em;

	@Override
	public void insertar(Alumno_asignatura entity) {
		em.persist(entity);		
	}

	@Override
	public void borrar(Alumno_asignatura entity) {
		em.remove(entity);		
	}

	@Override
	public List<Alumno_asignatura> buscarTodo() {
		List<Alumno_asignatura> a = (List<Alumno_asignatura>) em.createQuery("from Profesor").getResultList();
        return a;
	}
}