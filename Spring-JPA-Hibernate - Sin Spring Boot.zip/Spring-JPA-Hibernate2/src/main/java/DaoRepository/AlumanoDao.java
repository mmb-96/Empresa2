package DaoRepository;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

import Clases.Alumno;

@Repository
public class AlumanoDao implements DAO<Alumno, String> {
	
	@PersistenceContext
	private EntityManager em;

	@Override
	public void insertar(Alumno entity) {
		em.persist(entity);
	}

	@Override
	public void borrar(Alumno entity) {
		em.remove(entity);
	}

	@Override
	public List<Alumno> buscarTodo() {
		List<Alumno> a = (List<Alumno>) em.createQuery("from Alumno").getResultList();
        return a;
	}
}