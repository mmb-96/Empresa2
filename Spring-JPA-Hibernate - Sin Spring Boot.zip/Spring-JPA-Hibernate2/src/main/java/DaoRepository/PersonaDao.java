package DaoRepository;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

import Clases.Persona;

@Repository
public class PersonaDao implements DAO<Persona, String> {
	
	@PersistenceContext
	private EntityManager em;

	@Override
	public void insertar(Persona entity) {
		em.persist(entity);		
	}

	@Override
	public void borrar(Persona entity) {
		em.remove(entity);		
	}

	@Override
	public List<Persona> buscarTodo() {
		List<Persona> p = (List<Persona>) em.createQuery("from Persona").getResultList();
        return p;
	}
}