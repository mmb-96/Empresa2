package Servicios;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Clases.Alumno_asignatura;
import DaoRepository.AlumanoDao;
import DaoRepository.Alumno_asignaturaDao;

@Service
public class Alumno_asignaturaManager implements Manager<Alumno_asignatura> {

	@Autowired
	private Alumno_asignaturaDao alumnoAsignatura;
	
	@Override
	@Transactional
	public void insertar(Alumno_asignatura entity) {
		alumnoAsignatura.insertar(entity);		
	}

	@Override
	@Transactional
	public void borrar(Alumno_asignatura entity) {
		alumnoAsignatura.borrar(entity);		
	}

	@Override
	public List<Alumno_asignatura> buscarTodo() {
		return alumnoAsignatura.buscarTodo();
	}

}
