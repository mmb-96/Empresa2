package Servicios;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Clases.Titulacion;
import DaoRepository.TitulacionDao;

@Service
public class TitulacionManager implements Manager<Titulacion> {
	
	@Autowired
	private TitulacionDao titulacion;

	@Override
	@Transactional
	public void insertar(Titulacion entity) {
		titulacion.insertar(entity);	
	}

	@Override
	@Transactional
	public void borrar(Titulacion entity) {
		titulacion.borrar(entity);		
	}

	@Override
	public List<Titulacion> buscarTodo() {
		return titulacion.buscarTodo();
	}
}