package Servicios;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Clases.Profesor;
import DaoRepository.ProfesorDao;

@Service
public class ProfesorManager implements Manager<Profesor> {
	
	@Autowired
	private ProfesorDao profesor;

	@Override
	@Transactional
	public void insertar(Profesor entity) {
		profesor.insertar(entity);	
	}

	@Override
	@Transactional
	public void borrar(Profesor entity) {
		profesor.borrar(entity);		
	}

	@Override
	public List<Profesor> buscarTodo() {
		return profesor.buscarTodo();
	}
}
