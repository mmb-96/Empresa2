package Servicios;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Clases.Persona;
import DaoRepository.PersonaDao;

@Service
public class PersonaManager implements Manager<Persona> {
	
	@Autowired
	private PersonaDao persona;

	@Override
	@Transactional
	public void insertar(Persona entity) {
		persona.insertar(entity);	
	}

	@Override
	@Transactional
	public void borrar(Persona entity) {
		persona.borrar(entity);		
	}

	@Override
	public List<Persona> buscarTodo() {
		return persona.buscarTodo();
	}
}