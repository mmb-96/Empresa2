package Servicios;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Clases.Asignatura;
import DaoRepository.AsignaturaDao;

@Service
public class AsignaturaManager implements Manager<Asignatura> {
	
	@Autowired
	private AsignaturaDao asignatura;

	@Override
	@Transactional
	public void insertar(Asignatura entity) {
		asignatura.insertar(entity);		
	}

	@Override
	@Transactional
	public void borrar(Asignatura entity) {
		asignatura.borrar(entity);
		
	}

	@Override
	public List<Asignatura> buscarTodo() {
		return asignatura.buscarTodo();
	}

}
