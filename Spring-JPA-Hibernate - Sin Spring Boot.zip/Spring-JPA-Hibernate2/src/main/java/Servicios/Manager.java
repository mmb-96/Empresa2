package Servicios;

import java.util.List;

public interface Manager<T> {
	
	public void insertar(T entity);
	
	public void borrar(T entity);
	
	public List<T> buscarTodo();
}
