package Servicios;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import Clases.Alumno;
import DaoRepository.AlumanoDao;

@Service
public class AlumnoManager implements Manager<Alumno> {
	@Autowired
	private AlumanoDao alumnos;
	
	@Override
	@Transactional
	public void insertar(Alumno entity) {
		alumnos.insertar(entity);
	}
	
	@Override
	@Transactional
	public void borrar(Alumno entity) {
		alumnos.borrar(entity);	
	}

	@Override
	public List<Alumno> buscarTodo() {
		return alumnos.buscarTodo();
	}

}
