package Main;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import Clases.Alumno;
import Clases.Alumno_asignatura;
import Clases.Alumno_asignatura.CompuestaPK;
import Clases.Asignatura;
import Clases.Persona;
import Clases.Profesor;
import Clases.Titulacion;
import Servicios.Manager;

public class Main {

	public static void main(String[] args) {
		Persona p = new Persona("12Z", "aa", "aa", "aa", "aa", 1, "123", 1);
		Alumno a = new Alumno("6X");
		a.setDni("13Z");
		Profesor pr = new Profesor("2X");
		pr.setDni("14Z");
		Titulacion ti = new Titulacion("3T", "Hola");
		Asignatura as = new Asignatura("3AS", "Hola", 5, 2, 5, pr, ti, 5); 
		Alumno_asignatura aa = new Alumno_asignatura(new CompuestaPK(a, as, 10));
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring.xml");
		
		Manager<Alumno> mga = (Manager<Alumno>) ctx.getBean("alumnoManager");
		Manager<Profesor> mgpro = (Manager<Profesor>) ctx.getBean("profesorManager");
		Manager<Persona> mgpr = (Manager<Persona>) ctx.getBean("personaManager");
		Manager<Asignatura> mgas = (Manager<Asignatura>) ctx.getBean("asignaturaManager");
		Manager<Titulacion> mgti = (Manager<Titulacion>) ctx.getBean("titulacionManager");
		Manager<Alumno_asignatura> mgaa = (Manager<Alumno_asignatura>) ctx.getBean("alumno_asignaturaManager");
		
		mga.insertar(a);
		mgpro.insertar(pr);
		mgpr.insertar(p);
		mgti.insertar(ti);
		mgas.insertar(as);
		mgaa.insertar(aa);
	}
}