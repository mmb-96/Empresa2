package etc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import etc.Alumno_asignatura.CompuestaPK;

@SpringBootApplication
public class Main  implements CommandLineRunner{

	@Autowired
	AlumanoRepo ar;
	@Autowired
	PersonaRepo per;
	@Autowired
	ProfesorRepo prr;
	@Autowired
	TitulacionRepo tr;
	@Autowired
	AsignaturaRepo asr;
	@Autowired
	Alumno_asignaturaRepo aar;
	
	public static void main(String[] args) {

		SpringApplication.run(Main.class, args);
	}
	
	public void run(String... arg) throws Exception {
		//Alumno
		Alumno a = new Alumno("3X");
		a.setDni("6Z");
		System.out.println(ar.save(a));
		System.out.println(ar.findAll());
		
		//Profesor
		Profesor pr = new Profesor("1X");
		pr.setDni("8Z");
		prr.save(pr);
		pr.setApellido("JAJA");
		pr.setNombre("JEJE");
		System.out.println(prr.save(pr));
		
		
		//Persona
		Persona p = new Persona("7Z", "aa", "aa", "aa", "aa", 1, "123", 1);
		System.out.println(per.save(p));
		System.out.println(per.findById("7Z"));
		per.delete(p);
		System.out.println(per.findAll());
		
		//Titulacion
		Titulacion ti = new Titulacion("2T", "Hola");
		System.out.println(tr.save(ti));
		System.out.println(tr.findAll());
		
		//Asignatura
		Asignatura as = new Asignatura("2AS", "Hola", 5, 2, 5, pr, ti, 5);
		asr.save(as);
		
		//Alumno_asignatura
		Alumno_asignatura aa = new Alumno_asignatura(new CompuestaPK(a, as, 10));
		System.out.println(aar.save(aa));		
	}
}