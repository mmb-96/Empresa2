package etc;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Alumno_asignaturaRepo extends JpaRepository<Alumno_asignatura, String>{
	
}