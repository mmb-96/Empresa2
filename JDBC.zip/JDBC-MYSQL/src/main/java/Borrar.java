import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Borrar {

	public static void main(String[] args) throws ClassNotFoundException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		try {
			System.out.println("Estabeciendo conexi�n:");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/prueba", "root", "1234");
			Statement stm = con.createStatement();
			String sql = "DELETE FROM  Alumnos WHERE edad = 16";
			stm.executeUpdate(sql);
			
			sql = "SELECT nombre, edad FROM Alumnos";
			ResultSet rs = stm.executeQuery(sql);
			
			while(rs.next()) {
				int edad = rs.getInt("edad");
				String nombre = rs.getString("nombre");
				
				System.out.println("Alumno");
				System.out.println("Nobmre " + nombre);
				System.out.println("Edad "  + edad);
				System.out.println("-----------");
			}
			
			rs.close();
			stm.close();
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
