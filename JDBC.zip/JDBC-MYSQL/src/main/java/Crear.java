import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Crear {

	public static void main(String[] args) throws ClassNotFoundException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		try {
			System.out.println("Estabeciendo conexi�n:");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/prueba", "root", "1234");
			Statement stm = con.createStatement();
			System.out.println("Creado la base de datos:");
			String sql = "CREATE TABLE	Alumnos " +
						"(nombre VARCHAR(30)," +
						"edad INT)";
			stm.executeUpdate(sql);
			System.out.println("Base de datos creada.");
			stm.close();
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
