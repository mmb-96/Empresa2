import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Insertar {

	public static void main(String[] args) throws ClassNotFoundException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		try {
			System.out.println("Estabeciendo conexi�n:");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/prueba", "root", "1234");
			Statement stm = con.createStatement();
			String sql = "INSERT INTO Alumnos VALUES ('Manuel', 23)";
			stm.executeUpdate(sql);
			sql = "INSERT INTO Alumnos VALUES ('Pedro', 30)";
			stm.executeUpdate(sql);
			sql = "INSERT INTO Alumnos VALUES ('Ana', 55)";
			stm.executeUpdate(sql);
			sql = "INSERT INTO Alumnos VALUES ('Luis', 16)";
			stm.executeUpdate(sql);
			System.out.println("Datos insertados.");
			stm.close();
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
