import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Leer {
	
	public static void main(String[] args) throws ClassNotFoundException {
		
		Class.forName("org.h2.Driver");
		
		try {
			System.out.println("Estabeciendo conexi�n:");
			Connection con = DriverManager.getConnection("jdbc:h2:~/test", "sa", "");
			Statement stm = con.createStatement();
			String sql = "SELECT id, nombre, apellido, edad FROM Registro";
			ResultSet rs = stm.executeQuery(sql);
			
			while(rs.next()) {
				int id = rs.getInt("id");
				int edad = rs.getInt("edad");
				String nombre = rs.getString("nombre");
				String apellidos = rs.getString("apellido");
				
				System.out.println("Cliente " + id);
				System.out.println("-----------");
				System.out.println("Nobmre " + nombre + " Apellido " + apellidos);
				System.out.println("Edad "  + edad);
				System.out.println("-----------");
			}
			rs.close();
			stm.close();
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
