import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Insertar {

	public static void main(String[] args) throws ClassNotFoundException {
		
		Class.forName("org.h2.Driver");
		
		try {
			System.out.println("Estabeciendo conexi�n:");
			Connection con = DriverManager.getConnection("jdbc:h2:~/test", "sa", "");
			Statement stm = con.createStatement();
			String sql = "INSERT INTO Registro VALUES (1, 'Manuel', 'Melero', 23)";
			stm.executeUpdate(sql);
			sql = "INSERT INTO Registro VALUES (2, 'Pedro', 'Blaza', 30)";
			stm.executeUpdate(sql);
			sql = "INSERT INTO Registro VALUES (3, 'Ana', 'Per�z', 55)";
			stm.executeUpdate(sql);
			sql = "INSERT INTO Registro VALUES (4, 'Luis', 'Maldonado', 16)";
			stm.executeUpdate(sql);
			System.out.println("Datos insertados.");
			stm.close();
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
