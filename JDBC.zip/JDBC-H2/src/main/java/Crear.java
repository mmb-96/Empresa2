import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Crear {
	
	public static void main(String[] args) throws ClassNotFoundException {
		
		Class.forName("org.h2.Driver");
		
		try {
			System.out.println("Estabeciendo conexi�n:");
			Connection con = DriverManager.getConnection("jdbc:h2:~/test", "sa", "");
			Statement stm = con.createStatement();
			System.out.println("Creado la base de datos:");
			String sql = "CREATE TABLE	REGISTRO " +
						"(id INTEGER not null," +
						"nombre VARCHAR2(100)," +
						"apellido VARCHAR2(100)," +
						"edad INTEGER," +
						"PRIMARY KEY ( id ))";
			stm.executeUpdate(sql);
			System.out.println("Base de datos creada.");
			stm.close();
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}
}
