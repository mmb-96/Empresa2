import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TransaccionReadUncommited {

	private static Connection con1 = null;
	private static Connection con2 = null;
	private static Statement stm;
	private static ResultSet rs;
	
	public static void main(String[] args) throws ClassNotFoundException {
		
		final String url = "jdbc:mysql://localhost:3306/transacciones";
		final String user = "root";
		final String pass = "1234";
		String sql = null;		
		
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		try {
			con1 = DriverManager.getConnection(url, user, pass);
			con2 = DriverManager.getConnection(url, user, pass);
			con1.setAutoCommit(false);
			con2.setAutoCommit(false);
			
			con1.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
			
			stm = con1.createStatement();
			sql = "INSERT INTO alumno VALUES (4, 'Hola', 'Mundo');";
			stm.executeUpdate(sql);
			
			con2.setTransactionIsolation(Connection.TRANSACTION_READ_UNCOMMITTED);
			stm = con2.createStatement();
			rs = stm.executeQuery("SELECT * FROM  alumno");
			
			System.out.println("Primer select");
			while(rs.next()) {
				System.out.println(rs.getInt(1));
				System.out.println(rs.getString(2));
				System.out.println(rs.getString(3));
			}
			
			stm = con1.createStatement();
			sql = "UPDATE alumno SET nombre = 'Prueba' WHERE id = 4;";
			stm.executeUpdate(sql);
			
			stm = con2.createStatement();
			rs = stm.executeQuery("SELECT * FROM  alumno");
			
			System.out.println("Segundo select");
			while(rs.next()) {
				System.out.println(rs.getInt(1));
				System.out.println(rs.getString(2));
				System.out.println(rs.getString(3));
			}
			
			con1.rollback();
			
			stm = con2.createStatement();
			rs = stm.executeQuery("SELECT * FROM  alumno");
			
			System.out.println("Tercero select");
			while(rs.next()) {
				System.out.println(rs.getInt(1));
				System.out.println(rs.getString(2));
				System.out.println(rs.getString(3));
			}
			
			stm.close();
			con1.close();
			con2.close();
		} catch (SQLException e) {
			System.out.println("Se ha producido un error.");
		}
	}

}
