import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TransaccionReadSerializableYCommit {
	
	private static Connection con1 = null;
	private static Connection con2 = null;
	private static Statement stm1 = null;
	private static Statement stm2 = null;
	private static ResultSet rs;

	public static void main(String[] args)throws ClassNotFoundException {
		
		final String url = "jdbc:mysql://localhost:3306/transacciones";
		final String user = "root";
		final String pass = "1234";
		String sql = null;		
		
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		try {
			con1 = DriverManager.getConnection(url, user, pass);
			con2 = DriverManager.getConnection(url, user, pass);
			con1.setAutoCommit(false);
			con2.setAutoCommit(false);

			
			con1.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
			
			stm1 = con1.createStatement();
			sql = "SELECT * FROM  alumno";
			rs = stm1.executeQuery(sql);
			
			System.out.println("Primer select - Connection 1");
			while(rs.next()) {
				System.out.println(rs.getInt(1));
				System.out.println(rs.getString(2));
				System.out.println(rs.getString(3));
			}
			
			con2.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
			stm2 = con2.createStatement();
			sql = "SELECT * FROM  alumno";
			rs = stm2.executeQuery(sql);
			
			System.out.println("Primer select - Connection 2");
			while(rs.next()) {
				System.out.println(rs.getInt(1));
				System.out.println(rs.getString(2));
				System.out.println(rs.getString(3));
			}

			sql = "UPDATE alumno SET nombre = 'Hola' WHERE id = 4;";
			stm2.executeUpdate(sql);
			
			sql = "SELECT * FROM  alumno";
			rs = stm1.executeQuery(sql);
			
			System.out.println("Segundo select - Connection 1");
			while(rs.next()) {
				System.out.println(rs.getInt(1));
				System.out.println(rs.getString(2));
				System.out.println(rs.getString(3));
			}
			

			sql = "INSERT INTO alumno VALUES (5, 'Hola', 'Prueba');";
			stm2.executeUpdate(sql);
			
			
			sql = "SELECT * FROM  alumno";
			rs = stm1.executeQuery(sql);
			
			System.out.println("Tercero select - Connection 1");
			while(rs.next()) {
				System.out.println(rs.getInt(1));
				System.out.println(rs.getString(2));
				System.out.println(rs.getString(3));
			}
			con1.commit();
			
			stm1.close();
			stm2.close();
			con1.close();
			con2.close();
			rs.close();
		} catch (SQLException e) {
			System.out.println("Se ha producido un error."+e.getMessage());
		}
	}
}