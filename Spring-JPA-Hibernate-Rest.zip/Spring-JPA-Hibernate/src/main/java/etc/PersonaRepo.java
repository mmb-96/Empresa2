package etc;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.transaction.annotation.Transactional;

@RepositoryRestResource(path = "/persona")
public interface PersonaRepo extends JpaRepository<Persona, String>{
	
	@Query(value = "Select p from Persona p")
	List<Persona> findAllPersonas();
	
	@Query(value = "Select p.dni from Persona p  Where p.nombre like ?1")
	String findByName(String nombre);
	
	@Query(value = "Select p from Persona p Where p.dni like :dni")
	Persona findAlldni(@Param("dni") String dni);
	
	@Modifying
	@Query(value = "Update Persona set nombre = ?1 where dni = ?2")
	@Transactional
	void updatePerson(String nombre, String dni);
	
	@Modifying
	@Query(value = "Insert into Persona (dni, nombre, apellido, ciudad, direccioncalle, direccionnum, telefono, varon) values (:dni, :nombre, :apellido, :ciudad, :direccioncalle, :direccionnum, :telefono, :varon)", nativeQuery=true)
	@Transactional
	void insertPersonar(@Param("dni") String dni, @Param("nombre") String nombre, @Param("apellido") String apellido, @Param("ciudad") String ciudad, @Param("direccioncalle") String direccioncalle, @Param("direccionnum") int direccionnum, @Param("telefono") String telefono, @Param("varon") int varon);
}