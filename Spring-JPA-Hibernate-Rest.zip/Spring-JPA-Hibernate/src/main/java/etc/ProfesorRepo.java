package etc;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(path = "/profesor")
public interface ProfesorRepo extends JpaRepository<Profesor, String>{
	
}