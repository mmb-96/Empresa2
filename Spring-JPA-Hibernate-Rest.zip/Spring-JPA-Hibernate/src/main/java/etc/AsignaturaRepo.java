package etc;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(path = "/asignatura")
public interface AsignaturaRepo extends JpaRepository<Asignatura, String>{
	
}