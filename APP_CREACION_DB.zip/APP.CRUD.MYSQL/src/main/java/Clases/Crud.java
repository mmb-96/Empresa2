/**
 * 
 */
package Clases;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 * @author mmelerob
 *
 */
public class Crud {
	
	public int crearTabla(String tabla, String columna, String tipo) throws ClassNotFoundException {
		int error = 0;
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/crud", "root", "1234");
			Statement stm = con.createStatement();
			String sql = "CREATE TABLE	" + tabla + "(" + columna + " " + tipo +" PRIMARY KEY)";
			stm.executeUpdate(sql);
			stm.close();
			con.close();
			error = 1;
		} catch (Exception e) {
			error = -1;
		}
		return error;
	}
	
	public int insertColum(String tabla, String columna, String tipo, String opc) throws ClassNotFoundException {
		int error = 0;
		String opcnull;
		
		if (opc.equalsIgnoreCase("si")) {
			opcnull = "null";
		} else {
			opcnull = "not null";
		}
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/crud", "root", "1234");
			Statement stm = con.createStatement();
			String sql = "ALTER TABLE	" + tabla + " add " + columna + " " + tipo +" " + opcnull + ";";
			stm.executeUpdate(sql);
			stm.close();
			con.close();
			error = 1;
		} catch (Exception e) {
			error = -1;
		}
		return error;
	}
	
	public int deleteColum(String tabla, String columna) throws ClassNotFoundException {
		int error = 0;		

		Class.forName("com.mysql.cj.jdbc.Driver");
		
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/crud", "root", "1234");
			Statement stm = con.createStatement();
			String sql = "ALTER TABLE	" + tabla + " DROP COLUMN " + columna +";";
			stm.executeUpdate(sql);
			stm.close();
			con.close();
			error = 1;
		} catch (Exception e) {
			error = -1;
		}
		return error;
	}
	
	public int borrarTabla(String tabla) throws ClassNotFoundException {
		int error = 0;
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/crud", "root", "1234");
			Statement stm = con.createStatement();
			String sql = "DROP TABLE " + tabla;
			stm.executeUpdate(sql);
			stm.close();
			con.close();
			error = 1;
		} catch (Exception e) {
			error = -1;
		}
		return error;
	}
	
	public int insertDatos(String tabla, String campo, String valores) throws ClassNotFoundException {
		int error = 0;
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/crud", "root", "1234");
			Statement stm = con.createStatement();
			String sql = "INSERT INTO " + tabla + " ("+ campo + ") VALUES ("+valores+");";
			stm.executeUpdate(sql);
			stm.close();
			con.close();
			error = 1;
		} catch (Exception e) {
			error = -1;
		}
		return error;
	}
	
	public int modificarDatos(String tabla, String dato, String datosModif, String cual, String quien) throws ClassNotFoundException {
		int error = 0;
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/crud", "root", "1234");
			Statement stm = con.createStatement();
			String sql = "UPDATE " + tabla + " set " + dato + " = " + datosModif + " where "  + cual +  " = " + quien + ";";
			stm.executeUpdate(sql);
			stm.close();
			con.close();
			error = 1;
		} catch (Exception e) {
			error = -1;
		}
		return error;
	}
		
	public int borrarDatos(String tabla, String dato) throws ClassNotFoundException {
		int error = 0;
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/crud", "root", "1234");
			Statement stm = con.createStatement();
			String sql = "DELETE FROM " + tabla + " where " + dato;
			stm.executeUpdate(sql);
			stm.close();
			con.close();
			error = 1;
		} catch (Exception e) {
			error = -1;
		}
		return error;
	}
	
	public ArrayList<String> consulta(String consulta) throws ClassNotFoundException {
		ArrayList<String> list = new ArrayList<String>();
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/crud", "root", "1234");
			Statement stm = con.createStatement();
			String sql = consulta;
			ResultSet rs = stm.executeQuery(sql);
			
			int cant = rs.getMetaData().getColumnCount();
			
			while(rs.next()) {
				for(int i = 1; i <= cant; i++) {
					list.add(rs.getMetaData().getColumnName(i)+ " " + rs.getString(i));
				}
				
			}
			rs.close();
			stm.close();
			con.close();
		} catch (Exception e) {
		}
		return list;
	}
}