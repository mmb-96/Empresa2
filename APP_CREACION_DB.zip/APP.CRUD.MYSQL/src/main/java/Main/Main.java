package Main;

import java.util.Scanner;
import Clases.Crud;

public class Main {

	private static Scanner sc;
	private static Scanner sx;

	public static void main(String[] args) throws ClassNotFoundException {
		Crud c = new Crud();
		sc = new Scanner(System.in);
		sx = new Scanner(System.in);
		String opc = null;
		String tabla;
		String columna;
		String tipo;

		do {
			System.out.println("Introduzca una opci�n:\n"
								+ "1. Crear Tabla.\n"
								+ "2. Insertar columna a la tabla.\n"
								+ "3. Borrar columna de la tabla.\n"
								+ "4. Eliminar tabla.\n" 
								+ "5. Insertar datos.\n"
								+ "6. Modificar datos.\n"
								+ "7. Consultar datos.\n"
								+ "8. Borrar datos.\n" 
								+ "9. Salir");
			opc = sc.nextLine();
			switch (opc) {
			case "1":
				System.out.println("Nombre de la tabla:");
				tabla = sc.nextLine();
				System.out.println("Nombre de la columna:");
				columna = sc.nextLine();
				System.out.println("Eliga el tipo de dato (varchar, INT, date, etc):");
				tipo = sc.nextLine();
				if (c.crearTabla(tabla, columna, tipo) == 1) {
					System.out.println("La tabla se ha creado correctamente.");
				} else {
					System.out.println("Se ha producido un error o la tabla ya existe.");
				}
				break;
			case "2":
				System.out.println("Nombre de la tabla a a�adir columna:");
				tabla = sc.nextLine();
				System.out.println("Numero de columanas a a�adir:");
				int num = Integer.parseInt(sx.next());
				for (int i = 1; i <= num; i++) {
					System.out.println("Nombre de la columna:");
					columna = sc.nextLine();
					System.out.println("Eliga el tipo de dato (varchar, INT, date, etc):");
					tipo = sc.nextLine();
					System.out.println("Indica si la columna es nulla o no, medinate si o no:");
					String opcnull = sc.nextLine();
					System.out.println("");
					if (c.insertColum(tabla, columna, tipo, opcnull) == 1) {
						System.out.println("La tabla se ha modificado correctamente.");
					} else {
						System.out.println("Se ha producido un error o la tabla ya existe.");
					}
				}
				break;
			case "3":
				System.out.println("Nombre de la tabla:");
				tabla = sc.nextLine();
				System.out.println("Nombre de la columna:");
				columna = sc.nextLine();
				if (c.deleteColum(tabla, columna) == 1) {
					System.out.println("La columna se ha borrado correctamente.");
				} else {
					System.out.println("Se ha producido un error o la tabla ya existe.");
				}
				break;
			case "4":
				System.out.println("Nombre de la tabla:");
				tabla = sc.nextLine();
				if (c.borrarTabla(tabla) == 1) {
					System.out.println("La tabla se ha borrado correctamente.");
				} else {
					System.out.println("Se ha producido un error o la tabla ya no existe.");
				}
				break;
			case "5":
				System.out.println("Nombre de la tabla:");
				tabla = sc.nextLine();
				System.out.println("Campos de la tabla:");
				String campo = sc.nextLine();
				System.out.println("Valores de los campos a insertar:");
				String valore = sc.nextLine();
				
				if (c.insertDatos(tabla, campo, valore) == 1) {
					System.out.println("Los dato se han insertado correctamente.");
				} else {
					System.out.println("Se ha producido un error.");
				}
				break;
			case "6":
				System.out.println("Nombre de la tabla:");
				tabla = sc.nextLine();
				System.out.println("Datos a modificar:");
				String datos = sc.nextLine();
				System.out.println("Datos actualizado:");
				String datosModif = sc.nextLine();
				System.out.println("Datos de la tabla a la que cambiar:");
				String cual = sc.nextLine();
				System.out.println("Datos a quien cambiar:");
				String quien = sc.nextLine();
				if (c.modificarDatos(tabla, datos, datosModif, cual, quien) == 1) {
					System.out.println("Los dato se han actualizado correctamente.");
				} else {
					System.out.println("Se ha producido un error.");
				}
				break;
			case "7":
				System.out.println("Escribe la consulta a ejecutar:");
				String consulta = sc.nextLine();
				System.out.println(c.consulta(consulta));
				break;
			case "8":
				System.out.println("Nombre de la tabla:");
				tabla = sc.nextLine();
				System.out.println("Datos a borrar");
				String dato = sc.nextLine();
				if (c.borrarDatos(tabla, dato) == 1) {
					System.out.println("Los dato se han borrado correctamente.");
				} else {
					System.out.println("Se ha producido un error.");
				}
				break;
			case "9":
				System.out.println("Saliendo de la aplicaci�n...");
				break;
			default:
				System.out.println("Opci�n incorrecta.");
				break;
			}
		} while (!opc.equalsIgnoreCase("9"));

	}
}